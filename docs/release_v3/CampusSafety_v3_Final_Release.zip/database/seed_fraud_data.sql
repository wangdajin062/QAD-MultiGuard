-- TeleAntiFraud-28k + ChiFraud 数据集内置 SQL
-- 生成时间: 2026-04-24T07:55:17.779779

-- 清空旧测试数据
DELETE FROM user_case_favorites;
DELETE FROM fraud_cases;
DELETE FROM fraud_alerts;
DELETE FROM sms_keywords;

-- 案例库（8条，基于真实案例脱敏改编）
INSERT INTO fraud_cases (title, summary, content, category, risk_level, emoji, view_count, like_count, share_count, is_featured, tags, related_ids, status, published_at) VALUES ('冒充公安局「涉案资金冻结」骗局', '不法分子冒充公安局民警，以银行卡涉嫌洗钱为由，诱导大学生将资金转至「安全账户」，骗走28万元。', '【案情经过】
2024年3月，某高校大三学生小李接到一个陌生来电，对方自称是上海市公安局网络犯罪侦查大队民警「张警官」，告知小李其名下银行卡涉及一起跨省洗钱案件，目前已被公安机关列为协查对象。

对方操作专业，报出了小李的姓名、身份证号和家庭住址，令小李信以为真。「张警官」随后表示，为配合调查、证明清白，需要将名下所有资金转入指定的「安全账户」进行资产冻结核查，待案件终结后原路退回。

小李被吓到，按照对方指示，分三次将银行卡内28万元（含助学贷款和家人积蓄）转至对方账户。转账完成后对方失联，小李意识到被骗立即报警。

【诈骗特征】
① 自称公安/检察院/法院，使用「案件编号」「传票」等术语制造恐惧
② 要求绝对保密，不得告知家人朋友（防止受害者核实）
③ 转账至「安全账户」是核心话术，任何机构均不存在此操作
④ 通话全程使用语音通话，从不视频（防止身份暴露）

【防范要点】
公检法机关绝不会通过电话要求转账。接到此类电话请立即挂断，拨打110核实。', '冒充公检法', 'high', '🚨', 0, 0, 0, true, '[]', '[]', 'published', now());
INSERT INTO fraud_cases (title, summary, content, category, risk_level, emoji, view_count, like_count, share_count, is_featured, tags, related_ids, status, published_at) VALUES ('「检察院」发传票诈骗——真实对话还原', '诈骗分子以「检察院传票」为由，通过心理施压手段，骗取受害者转账12万元。', '【典型话术还原（来源：TeleAntiFraud-28k 语料）】

诈骗方：「您好，请问是×××吗？我是北京市检察院的工作人员，您名下有一张传票，案号XXXXXXX。」

受害者：「我？什么传票？」

诈骗方：「您的个人信息被犯罪分子冒用，涉及一起电信诈骗案，已有受害者指控您参与其中。根据程序，我们需要您配合调查。」

受害者：「可是我什么都没做……」

诈骗方：「我理解您的心情，但案件已进入司法程序。如果您拒绝配合，我们将对您采取强制措施。当然，如果您是清白的，只需配合资产核查……」

【行为特征分析（ChiFraud 框架）】
- 角色一（施压者）：制造紧迫感和法律威胁
- 角色二（安抚者）：表示理解，提供「解决方案」
- 核心目标：绕过受害者理性判断，直接触发转账行为

【识别要点】
真实检察院传票通过邮政送达，绝不会电话通知并要求转账。', '冒充公检法', 'high', '⚖️', 0, 0, 0, true, '[]', '[]', 'published', now());
INSERT INTO fraud_cases (title, summary, content, category, risk_level, emoji, view_count, like_count, share_count, is_featured, tags, related_ids, status, published_at) VALUES ('高校学生兼职刷单被骗5.6万元', '某大学生通过社交媒体找到「高薪刷单兼职」，初期顺利返佣，逐步被诱导大额垫付后人间蒸发。', '【案情经过】
2024年1月，大一新生小王在某短视频平台看到一条推送：「大学生兼职首选！每天2小时，日入300+，无需经验，即刻开始！」点击链接后被拉入一个微信群。

群主「任务助理」称，只需用自己账号帮商家刷单评价，每单佣金10%-15%，当天结算。前5单金额小（每单50-200元），佣金均按时到账，小王尝到甜头。

第6单开始，任务金额升至2000元，「因为高额单需要资质认证，完成后连同佣金一起退回」。小王转账，对方果然退回了2300元。小王完全放松警惕。

之后任务金额迅速升级至5000、10000、20000元，每次都以「系统故障」「任务未完成」「需要补单」为由要求再次垫付，直至小王凑不出钱，前后共损失5.6万元。

【诈骗模型（TeleAntiFraud-28k 刷单类型）】
阶段1（建立信任）→ 阶段2（小额验证）→ 阶段3（逐步升级）→ 阶段4（制造债务）

【警示】
刷单本身违法！正规平台绝不要求垫付本金。收到此类邀请请立即举报。', '兼职刷单', 'high', '⚡', 0, 0, 0, true, '[]', '[]', 'published', now());
INSERT INTO fraud_cases (title, summary, content, category, risk_level, emoji, view_count, like_count, share_count, is_featured, tags, related_ids, status, published_at) VALUES ('「无抵押秒到账」助学贷款诈骗', '冒充助学贷款机构，以「刷流水」「解冻费」为由骗取学生钱财，且不放款。', '【典型话术】
「同学您好，我们是××助学基金，专为大学生提供低息免息贷款，最高5万，当天放款，无需担保……」

【诈骗流程】
1. 引导下载「官方APP」（实为钓鱼软件）
2. 填写个人信息、银行卡号（信息被盗）
3. 以「流水不足」为由要求先转入本金「激活额度」
4. 以「手续费」「解冻费」「刷流水」等名义持续诈骗
5. 最终拉黑，一分不贷

【识别要点】
① 正规贷款只收息，不预先收取任何费用
② 不在应用商店的APP都不可信
③ 「当天放款」「无需审核」必是骗局', '助学贷款', 'high', '🔔', 0, 0, 0, true, '[]', '[]', 'published', now());
INSERT INTO fraud_cases (title, summary, content, category, risk_level, emoji, view_count, like_count, share_count, is_featured, tags, related_ids, status, published_at) VALUES ('「网恋」背后的杀猪盘投资陷阱', '以恋爱为包装，诱导受害者在虚假平台投资，最终血本无归。某大学生损失23万元。', '【案情经过】
小陈通过某交友APP认识了「Lily」，自称海外华人，形象气质俱佳。两人聊得投机，「Lily」渐渐透露自己在做外汇投资，月收益30%+，并表示可以带小陈一起赚钱。

小陈抱着试试的心态，在「Lily」推荐的平台投入2000元，平台显示收益立竿见影，提现也成功了。小陈兴奋起来，陆续追加投资。

当账户显示盈利达到30万时，小陈申请全额提现，平台客服告知「需缴纳20%资金监管费才能解冻」，小陈已无力支付，方才意识到被骗，前后共损失23万元。

【杀猪盘特征（TeleAntiFraud-28k 情感欺诈类型）】
① 主动搭讪，感情升温异常迅速
② 不经意间提到「稳赚的投资」
③ 平台数据可随意篡改，让你看到「盈利」
④ 提现时以各种理由要求继续充值

【大学生防范建议】
陌生人主动搭讪+引导投资 = 100%诈骗，立即拉黑。', '杀猪盘', 'high', '🐷', 0, 0, 0, true, '[]', '[]', 'published', now());
INSERT INTO fraud_cases (title, summary, content, category, risk_level, emoji, view_count, like_count, share_count, is_featured, tags, related_ids, status, published_at) VALUES ('二手平台「超低价」陷阱', '以远低于市场价的商品吸引买家，收款后以各种理由拒绝发货或失联。', '【常见场景】
某同学在二手平台看到一台「9成新MacBook Pro」，标价2000元（市价12000元），卖家表示「急需用钱，价格可商量」。

私信交流后，卖家以「平台手续费高」为由要求微信转账，并表示「先付定金500元锁定」。付款后卖家各种拖延，最终拉黑。

【识别技巧（ChiFraud 文本检测特征）】
- 价格明显低于市场价（<30%）→ 高风险信号
- 要求脱离平台私下交易 → 放弃平台保障
- 催促付款、限时优惠 → 制造紧迫感
- 无实物视频/当面交易意愿 → 无实物可能

【安全建议】
坚持走平台担保交易，拒绝私下转账，坚持验货后付款。', '虚假购物', 'medium', '🛒', 0, 0, 0, false, '[]', '[]', 'published', now());
INSERT INTO fraud_cases (title, summary, content, category, risk_level, emoji, view_count, like_count, share_count, is_featured, tags, related_ids, status, published_at) VALUES ('「征信修复」骗局', '声称可修复个人征信记录，实则骗取服务费，征信无法修复。', '【话术特征】
「您好，我们是专业征信修复机构，可帮您消除银行逾期记录，费用3000元，成功后收取，先垫付……」

【真相】
征信记录由人民银行管理，任何机构无权修改。所谓「修复」均为骗局。

【受害群体】
有过信用卡逾期、网贷记录的大学生，急于「洗白」征信，成为主要目标群体。

【防范要点】
① 征信问题只能等待时效消除（一般5-7年）
② 可登录央行征信中心官网（pbccrc.org.cn）免费查询
③ 任何收费「修复」均为诈骗', '网络贷款', 'medium', '📋', 0, 0, 0, false, '[]', '[]', 'published', now());
INSERT INTO fraud_cases (title, summary, content, category, risk_level, emoji, view_count, like_count, share_count, is_featured, tags, related_ids, status, published_at) VALUES ('「购物退款」钓鱼短信骗局', '冒充电商客服，以商品质量问题主动联系退款，实则诱导扫码或填写银行卡信息。', '【短信样本（TeleAntiFraud-28k SMS 类型）】
「您好，您购买的商品检测出质量问题，已为您申请三倍赔偿，点击链接完成申领：http://t.cn/xxxxx」

【钓鱼链接特征】
- 域名非官方（非 .taobao.com .jd.com）
- 要求填写姓名、身份证、银行卡号及验证码
- 页面设计粗糙，存在错别字

【新型变种】
诈骗方会提前掌握真实订单信息（可能来自数据泄露），使退款电话更具可信度。

【安全原则】
退款问题只在官方APP内处理，永远不在第三方链接填写银行卡信息。', '冒充客服', 'medium', '📱', 0, 0, 0, false, '[]', '[]', 'published', now());

-- 预警库（5条）
INSERT INTO fraud_alerts (title, content, risk_level, emoji, is_urgent, push_count, read_count, report_count, tags, status, published_at) VALUES ('🚨 紧急预警：冒充公安局「安全账户」诈骗高发', '近期校内多名同学接到自称「公安局民警」的电话，以「银行卡涉案、需转账至安全账户配合调查」为由实施诈骗。请注意：①公检法机关绝不电话要求转账；②「安全账户」不存在；③接到此类电话立即挂断，拨打110核实。', 'high', '🚨', true, 0, 0, 0, '[]', 'published', now());
INSERT INTO fraud_alerts (title, content, risk_level, emoji, is_urgent, push_count, read_count, report_count, tags, status, published_at) VALUES ('⚡ 预警：刷单兼职诈骗换新话术，以「任务助理」身份出现', '诈骗分子近期改变话术，以「电商代运营助理」「直播间助播员」等包装招募刷单人员。前期小额任务正常返佣，一旦信任建立即要求大额垫付。请勿参与任何形式的刷单活动，该行为本身违法。', 'high', '⚡', true, 0, 0, 0, '[]', 'published', now());
INSERT INTO fraud_alerts (title, content, risk_level, emoji, is_urgent, push_count, read_count, report_count, tags, status, published_at) VALUES ('📱 预警：虚假「征信修复」短信大量发送', '近期大量短信声称可「一周内修复征信记录，消除逾期影响」，要求添加微信详谈。征信记录由中国人民银行统一管理，任何第三方机构无权修改，此类信息均为诈骗。', 'medium', '📋', false, 0, 0, 0, '[]', 'published', now());
INSERT INTO fraud_alerts (title, content, risk_level, emoji, is_urgent, push_count, read_count, report_count, tags, status, published_at) VALUES ('🐷 预警：交友APP「杀猪盘」投资诈骗活跃', '近期多名同学反映通过交友软件认识「海外华人」后被引导至虚假投资平台，初期可提现，随后以「监管费」「解冻金」为由持续骗钱。请对网络恋人主动推荐的「稳赚投资」保持高度警惕。', 'high', '🐷', false, 0, 0, 0, '[]', 'published', now());
INSERT INTO fraud_alerts (title, content, risk_level, emoji, is_urgent, push_count, read_count, report_count, tags, status, published_at) VALUES ('🔔 预警：助学金诈骗短信冒充教育部门', '收到「教育部门」发放助学金通知，点击链接填写信息后账户被盗刷。正规助学金发放通过学校官方渠道通知，不会通过短信链接要求填写银行卡信息。', 'medium', '🔔', false, 0, 0, 0, '[]', 'published', now());

-- 关键词库（50条，基于 TeleAntiFraud-28k + ChiFraud）
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('安全账户', 98, '冒充公检法', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=98;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('资产冻结', 95, '冒充公检法', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=95;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('涉案资金', 95, '冒充公检法', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=95;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('配合调查', 90, '冒充公检法', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=90;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('洗钱嫌疑', 95, '冒充公检法', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=95;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('案件编号', 88, '冒充公检法', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=88;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('网络通缉令', 92, '冒充公检法', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=92;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('刑事拘留', 90, '冒充公检法', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=90;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('检察院传票', 93, '冒充公检法', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=93;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('司法冻结', 90, '冒充公检法', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=90;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('公安部备案', 88, '冒充公检法', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=88;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('协助侦查', 85, '冒充公检法', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=85;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('刷单', 88, '兼职刷单', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=88;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('垫付', 82, '兼职刷单', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=82;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('返佣', 78, '兼职刷单', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=78;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('任务助理', 80, '兼职刷单', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=80;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('日入三百', 75, '兼职刷单', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=75;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('刷流水', 85, '兼职刷单', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=85;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('好评返现', 70, '兼职刷单', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=70;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('兼职佣金', 72, '兼职刷单', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=72;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('无抵押放款', 85, '网络贷款', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=85;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('秒到账', 80, '网络贷款', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=80;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('征信修复', 90, '网络贷款', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=90;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('消除逾期', 88, '网络贷款', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=88;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('激活额度', 85, '网络贷款', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=85;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('解冻费', 88, '网络贷款', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=88;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('手续费先付', 90, '网络贷款', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=90;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('低息免审', 80, '网络贷款', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=80;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('稳定收益', 75, '杀猪盘', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=75;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('月收益30', 85, '杀猪盘', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=85;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('量化交易', 70, '杀猪盘', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=70;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('内部消息', 78, '杀猪盘', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=78;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('带你赚钱', 80, '杀猪盘', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=80;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('监管费', 88, '杀猪盘', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=88;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('资金托管', 85, '杀猪盘', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=85;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('立即转账', 92, '紧迫性', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=92;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('马上处理', 75, '紧迫性', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=75;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('限时', 70, '紧迫性', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=70;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('今天必须', 78, '紧迫性', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=78;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('否则后果', 80, '紧迫性', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=80;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('不得告知', 85, '紧迫性', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=85;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('严格保密', 82, '紧迫性', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=82;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('点击链接', 72, '钓鱼', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=72;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('扫码领取', 75, '钓鱼', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=75;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('验证码', 65, '钓鱼', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=65;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('银行卡信息', 80, '钓鱼', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=80;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('三倍赔偿', 82, '钓鱼', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=82;
INSERT INTO sms_keywords (keyword, risk_weight, category, is_active, hit_count) VALUES ('退款申请', 68, '钓鱼', true, 0) ON CONFLICT (keyword) DO UPDATE SET risk_weight=68;