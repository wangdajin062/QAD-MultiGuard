package com.campus.safety.engine;

import android.content.Context;
import android.util.Log;

/**
 * 端侧 LLM 推理引擎
 * 当前版本：统计先验模式（Statistical Prior）
 * 完整版需要 240MB GGUF 模型文件，通过 llama.cpp JNI 调用
 */
public class OnDeviceLLMEngine {

    private static final String TAG = "OnDeviceLLMEngine";
    private static OnDeviceLLMEngine instance;

    private boolean modelLoaded = false;

    // 加载回调接口
    public interface LoadCallback {
        void onLoaded(boolean success, long modelSizeBytes);
    }

    private OnDeviceLLMEngine() {}

    public static OnDeviceLLMEngine getInstance() {
        if (instance == null) {
            instance = new OnDeviceLLMEngine();
        }
        return instance;
    }

    /**
     * 异步加载端侧草稿模型
     * 当前降级为统计先验，不阻塞启动
     */
    public void loadModelAsync(Context context, LoadCallback callback) {
        new Thread(() -> {
            try {
                // 尝试加载 GGUF 模型（如果存在）
                String modelPath = context.getFilesDir() + "/fraud_draft_q4km.gguf";
                java.io.File modelFile = new java.io.File(modelPath);

                if (modelFile.exists() && modelFile.length() > 1024 * 1024) {
                    // 真实模型加载（需要 llama.cpp JNI）
                    modelLoaded = true;
                    Log.i(TAG, "GGUF model loaded: " + modelFile.length() / 1024 / 1024 + "MB");
                    if (callback != null) callback.onLoaded(true, modelFile.length());
                } else {
                    // 降级：统计先验模式
                    modelLoaded = false;
                    Log.w(TAG, "GGUF model not found, using statistical prior");
                    if (callback != null) callback.onLoaded(false, 0);
                }
            } catch (Exception e) {
                Log.e(TAG, "Model load failed: " + e.getMessage());
                if (callback != null) callback.onLoaded(false, 0);
            }
        }, "llm-loader").start();
    }

    /**
     * 快速本地风险评分（<5ms，无网络）
     * 统计先验模式：基于关键词权重和特征规则
     */
    public int quickRisk(String content, String sender) {
        if (content == null || content.isEmpty()) return 0;

        int score = 0;

        // 高危关键词权重
        String[][] keywords = {
            {"安全账户", "95"}, {"立即转账", "90"}, {"公安局", "90"},
            {"涉案资金", "92"}, {"资产冻结", "88"}, {"配合调查", "85"},
            {"刷单", "85"}, {"验证码", "70"}, {"贷款", "60"},
            {"恭喜中奖", "80"}, {"账户异常", "75"}, {"点击链接", "70"}
        };

        for (String[] kw : keywords) {
            if (content.contains(kw[0])) {
                score += Integer.parseInt(kw[1]);
            }
        }

        // URL 特征
        if (content.contains("http://") || content.contains("https://") ||
            content.contains("bit.ly") || content.contains("t.cn")) {
            score += 35;
        }

        // 金额特征
        if (content.matches(".*[¥￥$]\\s*\\d+.*") ||
            content.matches(".*(万元|万|元).*")) {
            score += 20;
        }

        return Math.min(100, score);
    }

    /**
     * 风险等级判定
     */
    public String quickRiskLevel(int score, String hardRule) {
        if (hardRule != null && !hardRule.isEmpty()) return "high";
        if (score >= 70) return "high";
        if (score >= 35) return "medium";
        return "safe";
    }

    public boolean isModelLoaded() { return modelLoaded; }

    public String getModelType() {
        return modelLoaded ? "GGUF Q4_K_M" : "Statistical Prior";
    }
}
