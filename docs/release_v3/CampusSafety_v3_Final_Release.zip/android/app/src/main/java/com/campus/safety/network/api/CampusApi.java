package com.campus.safety.network.api;

import com.campus.safety.model.*;
import java.util.Map;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.*;
import androidx.annotation.Nullable;

public interface CampusApi {

    // ── Auth ──────────────────────────────────────────────────
    @POST("v1/auth/send-code")
    Call<ApiResponse<Map<String, Object>>> sendCode(@Body Map<String, String> body);

    @POST("v1/auth/login")
    Call<ApiResponse<LoginResponse>> login(@Body Map<String, String> body);

    // ── Calls ─────────────────────────────────────────────────
    @GET("v1/calls/check")
    Call<ApiResponse<PhoneCheckResult>> checkPhone(@Query("phone") String phone);

    @GET("v1/calls/history")
    Call<ApiResponse<PageResult<CallLog>>> getCallHistory(
        @Query("page") int page, @Query("limit") int limit);

    @POST("v1/calls/report")
    Call<ApiResponse<Map<String, Object>>> reportPhone(@Body Map<String, String> body);

    // ── SMS ───────────────────────────────────────────────────
    @POST("v1/sms/analyze")
    Call<ApiResponse<SmsAnalyzeResult>> analyzeSms(@Body SmsAnalyzeRequest body);

    // ── Cases ─────────────────────────────────────────────────
    @GET("v1/cases")
    Call<ApiResponse<PageResult<FraudCase>>> getCases(
        @Query("category") @Nullable String category,
        @Query("keyword") @Nullable String keyword,
        @Query("page") int page,
        @Query("limit") int limit);

    @GET("v1/cases/{id}")
    Call<ApiResponse<FraudCase>> getCaseDetail(@Path("id") long id);

    @POST("v1/cases/{id}/favorite")
    Call<ApiResponse<Map<String, Object>>> toggleFavorite(@Path("id") long id);

    // ── Alerts ────────────────────────────────────────────────
    @GET("v1/alerts")
    Call<ApiResponse<PageResult<FraudAlert>>> getAlerts(
        @Query("page") int page, @Query("limit") int limit);

    @GET("v1/alerts/latest")
    Call<ApiResponse<List<FraudAlert>>> getLatestAlerts();

    // ── Reports ───────────────────────────────────────────────
    @POST("v1/reports")
    Call<ApiResponse<Map<String, Object>>> submitReport(@Body ReportRequest body);

    // ── User ──────────────────────────────────────────────────
    @GET("v1/user/stats")
    Call<ApiResponse<UserStats>> getUserStats();

    @POST("v1/user/device")
    Call<ApiResponse<Map<String, Object>>> registerDevice(@Body Map<String, String> body);

    @GET("v1/user/home")
    Call<ApiResponse<HomeData>> getHomeData();

    // ── Inference ─────────────────────────────────────────────
    @POST("v1/infer/fast")
    Call<ApiResponse<InferenceResult>> fastInfer(@Body MultimodalRequest body);

    @POST("v1/infer/voice")
    Call<ApiResponse<InferenceResult>> voiceInfer(@Body Map<String, Object> body);

    @POST("v1/infer/feedback")
    Call<ApiResponse<Map<String, Object>>> sendFeedback(@Body FeedbackRequest body);

    @GET("v1/infer/model-status")
    Call<ApiResponse<ModelStatus>> getModelStatus();
}
