package com.campus.safety.model;
import java.util.Map;

/**
 * SSE 流事件模型 — 对应 /v1/infer/stream 各阶段
 */
public class CoTStreamEvent {
    public String event;      // fast_detection | immediate_alert | spec_draft | cot_stream | final_result | error
    public String stage;      // 内部阶段：draft|cot|final
    public String risk_level;
    public Integer risk_score;
    public Double confidence;
    public Double latency_ms;
    public String chunk;       // CoT 文本片段
    public String cot_reasoning;
    public Double acceptance_rate;
    public Double speedup_factor;
    public Map<String, Integer> modalities;
}
