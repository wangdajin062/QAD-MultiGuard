package com.campus.safety.ml;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 端侧短信特征提取器（纯 Java，<5ms）
 * =======================================
 * 重要：原文在本方法执行后立即被 GC 回收，不经任何网络传输
 * 产出 12 维特征向量与后端 SMS Feature Vec 严格对齐
 */
public class SmsFeatureExtractor {

    // ── 预编译正则 ──────────────────────────────────────────
    private static final Pattern URL_PATTERN = Pattern.compile(
        "(https?://|www\\.)[\\w\\-]+(\\.[\\w\\-]+)+[/\\w\\-._~:?#\\[\\]@!$&'()*+,;=]*",
        Pattern.CASE_INSENSITIVE);
    private static final Pattern MONEY_PATTERN = Pattern.compile(
        "[¥￥$]\\s*\\d+|\\d+\\s*(元|万元|万|块|RMB)", Pattern.CASE_INSENSITIVE);
    private static final Pattern DIGIT_PATTERN = Pattern.compile("\\d");

    // ── 关键词权重表（与后端同步） ──────────────────────────
    private static final Map<String, Integer> KW_WEIGHT = new HashMap<>();
    static {
        KW_WEIGHT.put("安全账户", 100);
        KW_WEIGHT.put("立即转账", 90); KW_WEIGHT.put("公安局", 90);
        KW_WEIGHT.put("涉案资金", 92); KW_WEIGHT.put("资产冻结", 88);
        KW_WEIGHT.put("配合调查", 85); KW_WEIGHT.put("刷单", 85);
        KW_WEIGHT.put("刷好评", 80);   KW_WEIGHT.put("解冻", 80);
        KW_WEIGHT.put("验证码", 70);   KW_WEIGHT.put("贷款", 60);
        KW_WEIGHT.put("兼职", 45);     KW_WEIGHT.put("助学贷款", 70);
        KW_WEIGHT.put("内部名额", 65); KW_WEIGHT.put("恭喜中奖", 80);
        KW_WEIGHT.put("账户异常", 75); KW_WEIGHT.put("点击链接", 70);
    }

    private static final String[] URGENCY_WORDS = {
        "立即", "限时", "否则", "马上", "紧急", "立刻", "尽快", "务必",
        "倒计时", "截止", "最后", "仅剩"
    };
    private static final String[] AUTHORITY_WORDS = {
        "公安", "警察", "银行", "辅导员", "学校", "财务处",
        "教务处", "客服", "招生办", "政府", "国家", "税务"
    };
    private static final String[] HARD_RULES = {
        "安全账户", "公安冻结", "配合调查转账", "涉案资金"
    };

    // ── 提取结果容器 ────────────────────────────────────────
    public static class Features {
        public List<Float> vector = new ArrayList<>(12);   // 12 维特征
        public List<String> hitKeywords = new ArrayList<>(); // 命中关键词
        public String ruleTriggered;                       // 硬规则触发名
        public boolean hasUrl;
        public int urlCount;
        public boolean moneyMentioned;
        public boolean impersonation;
        public double urgencyScore;
        public int charCount;
        public double digitRatio;
        public boolean senderIsNumber;
        public String sampleHash;                          // SHA-256 (特征向量哈希，用于反馈)

        /** 本地快速评分（<5ms） */
        public int quickScore() {
            int score = 0;
            for (String kw : hitKeywords) score += KW_WEIGHT.getOrDefault(kw, 10);
            if (hasUrl)         score += 40;
            if (moneyMentioned) score += 20;
            if (impersonation)  score += 25;
            score += (int)(urgencyScore * 30);
            return Math.min(100, score);
        }

        public String quickRiskLevel() {
            int s = quickScore();
            if (ruleTriggered != null) return "high";
            if (s >= 70) return "high";
            if (s >= 35) return "medium";
            return "safe";
        }
    }

    /** 主提取方法：content 为 SMS 原文（仅在内存中处理，不上传） */
    public static Features extract(String content, String sender) {
        Features f = new Features();
        if (content == null || content.isEmpty()) {
            for (int i = 0; i < 12; i++) f.vector.add(0f);
            return f;
        }

        // 1) 硬规则优先
        for (String hard : HARD_RULES) {
            if (content.contains(hard)) {
                f.ruleTriggered = hard;
                break;
            }
        }

        // 2) 关键词命中
        for (String kw : KW_WEIGHT.keySet()) {
            if (content.contains(kw)) f.hitKeywords.add(kw);
        }
        int totalWeight = 0;
        for (String kw : f.hitKeywords) totalWeight += KW_WEIGHT.get(kw);

        // 3) 结构特征
        Matcher urlM = URL_PATTERN.matcher(content);
        int urlCount = 0;
        while (urlM.find()) urlCount++;
        f.hasUrl = urlCount > 0;
        f.urlCount = urlCount;
        f.moneyMentioned = MONEY_PATTERN.matcher(content).find();

        // 4) 冒充检测
        for (String w : AUTHORITY_WORDS) {
            if (content.contains(w)) { f.impersonation = true; break; }
        }

        // 5) 紧迫度评分
        int urgencyHits = 0;
        for (String w : URGENCY_WORDS) if (content.contains(w)) urgencyHits++;
        f.urgencyScore = Math.min(1.0, urgencyHits / 3.0);

        // 6) 长度与数字密度
        f.charCount = content.length();
        Matcher dm = DIGIT_PATTERN.matcher(content);
        int digitCount = 0;
        while (dm.find()) digitCount++;
        f.digitRatio = f.charCount == 0 ? 0 : (double) digitCount / f.charCount;

        // 7) 发件人纯数字
        f.senderIsNumber = sender != null && sender.replaceAll("[^0-9]", "").length() >= 5;

        // 8) 12 维特征向量（与后端对齐）
        f.vector = Arrays.asList(
            (float) Math.min(f.hitKeywords.size() / 5.0, 1.0),
            (float) Math.min(totalWeight / 100.0, 1.0),
            (float) f.urgencyScore,
            f.hasUrl ? 1f : 0f,
            (float) Math.min(urlCount / 3.0, 1.0),
            f.moneyMentioned ? 1f : 0f,
            f.impersonation ? 1f : 0f,
            (float) Math.min(f.charCount / 300.0, 1.0),
            (float) f.digitRatio,
            f.senderIsNumber ? 1f : 0f,
            (!f.hitKeywords.isEmpty() && f.hasUrl) ? 1f : 0f,
            (f.impersonation && f.moneyMentioned) ? 1f : 0f
        );

        // 9) 特征向量哈希（用于在线反馈样本去重）
        f.sampleHash = Utils.sha256(f.vector.toString() + (sender == null ? "" : sender));
        return f;
    }

    public static List<String> getTrackedKeywords() {
        return Collections.unmodifiableList(new ArrayList<>(KW_WEIGHT.keySet()));
    }
}
