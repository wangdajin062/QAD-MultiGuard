package com.campus.safety.network.interceptor;

import android.content.Context;
import androidx.annotation.NonNull;
import com.campus.safety.util.TokenManager;
import java.io.IOException;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

/**
 * JWT Token 自动注入拦截器
 * - 登录/发码端点跳过
 * - 其他所有请求附带 Authorization: Bearer <token>
 */
public class AuthInterceptor implements Interceptor {

    private static final String[] SKIP_PATHS = {
        "/v1/auth/send-code", "/v1/auth/login"
    };

    private final Context ctx;
    public AuthInterceptor(Context ctx) { this.ctx = ctx.getApplicationContext(); }

    @NonNull @Override
    public Response intercept(@NonNull Chain chain) throws IOException {
        Request original = chain.request();
        String path = original.url().encodedPath();

        for (String skip : SKIP_PATHS) {
            if (path.endsWith(skip)) return chain.proceed(original);
        }

        String token = TokenManager.getToken(ctx);
        if (token == null || token.isEmpty()) return chain.proceed(original);

        Request authed = original.newBuilder()
            .header("Authorization", "Bearer " + token)
            .header("X-Client-Version", "3.0.0")
            .header("X-Platform", "android")
            .build();

        return chain.proceed(authed);
    }
}
