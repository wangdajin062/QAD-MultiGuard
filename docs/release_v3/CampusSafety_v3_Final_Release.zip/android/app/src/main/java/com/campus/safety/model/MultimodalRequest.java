package com.campus.safety.model;
import java.util.List;

public class MultimodalRequest {
    public List<Float> sms_features;
    public String sms_text_summary;
    public List<Float> call_features;
    public String phone_number;
    public List<Float> url_features;
    public List<Float> audio_embedding;
    public String voice_text;
    public String session_id;
    public boolean enable_cot = true;
}
