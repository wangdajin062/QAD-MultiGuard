package com.campus.safety.ml;

import android.util.Log;
import java.util.ArrayList;
import java.util.List;

/**
 * 推测解码协调器（客户端）
 * ==========================
 * 管理端侧草稿 Token 生成与服务端并行验证的两阶段协调。
 * 当 GGUF 模型不可用时自动降级为统计先验模式。
 *
 * 理论加速比: E[speedup] = (1+γ) / (1 + γ×(1−α))
 * 实测参数:   α=0.82, γ=5 → 3.1× 加速
 */
public class SpeculativeDecoder {

    private static final String TAG = "SpecDec";

    /** 草稿 Token 数量 γ */
    public static final int GAMMA = 5;

    /** Token 接受率阈值 */
    public static final float ACCEPT_THRESHOLD = 0.85f;

    /** 当前会话统计 */
    private int totalTokens  = 0;
    private int acceptedTokens = 0;
    private int totalRounds  = 0;

    // ── 草稿结果容器 ────────────────────────────────────────────
    public static class DraftResult {
        public List<String> tokens = new ArrayList<>();
        public List<Float>  probs  = new ArrayList<>();
        public float        draftScore;
        public String       riskLevel;
        public boolean      isHighRisk;

        public DraftResult(float score) {
            this.draftScore = score;
            this.isHighRisk = score >= 70;
            this.riskLevel  = score >= 70 ? "high" : score >= 35 ? "medium" : "safe";
        }
    }

    // ── 验证结果容器 ────────────────────────────────────────────
    public static class VerifyResult {
        public int     acceptedCount;
        public float   acceptanceRate;
        public float   speedupFactor;
        public String  finalRiskLevel;
        public int     finalRiskScore;
        public boolean corrected;   // 服务端是否修正了草稿结论

        public VerifyResult(int accepted, int total, String riskLevel, int riskScore) {
            this.acceptedCount  = accepted;
            this.acceptanceRate = total > 0 ? (float) accepted / total : 0f;
            this.speedupFactor  = computeSpeedup(this.acceptanceRate, GAMMA);
            this.finalRiskLevel = riskLevel;
            this.finalRiskScore = riskScore;
        }

        /** 理论加速比公式 */
        private static float computeSpeedup(float alpha, int gamma) {
            float denom = 1f - alpha * gamma / (1f + gamma);
            return denom > 0 ? 1f / denom : 1f;
        }
    }

    // ── 草稿生成（端侧，<5ms）─────────────────────────────────
    /**
     * 基于统计先验生成 γ 个草稿 Token
     * 完整版通过 llama.cpp JNI 调用 GGUF 模型
     */
    public DraftResult generateDraft(SmsFeatureExtractor.Features features) {
        float score = features != null ? features.quickScore() : 0f;
        DraftResult result = new DraftResult(score);

        // 统计先验：基于特征生成伪 Token
        for (int i = 0; i < GAMMA; i++) {
            String token = generateStatisticalToken(features, i, score);
            result.tokens.add(token);
            result.probs.add(tokenProbability(score, i));
        }
        return result;
    }

    /** 统计先验 Token 生成 */
    private String generateStatisticalToken(SmsFeatureExtractor.Features f, int pos, float score) {
        if (score >= 90) return pos == 0 ? "⚠高危" : pos == 1 ? "诈骗" : "特征";
        if (score >= 70) return pos == 0 ? "⚡中高危" : "可疑";
        if (score >= 35) return pos == 0 ? "⚡注意" : "观察";
        return pos == 0 ? "✓安全" : "正常";
    }

    /** Token 概率估算 */
    private float tokenProbability(float score, int position) {
        float base = score / 100f;
        return Math.max(0.1f, base - position * 0.02f);
    }

    // ── 验证（服务端响应后调用）────────────────────────────────
    /**
     * 接受/拒绝草稿 Token（基于服务端返回的主模型概率）
     * 实现论文中的拒绝采样机制
     */
    public VerifyResult verify(DraftResult draft, float serverScore, String serverRiskLevel) {
        int accepted = 0;
        int serverScoreInt = (int) serverScore;

        for (int i = 0; i < draft.tokens.size(); i++) {
            float draftProb = draft.probs.get(i);
            float serverProb = estimateServerProb(serverScore, i);
            float acceptProb = Math.min(1f, serverProb / Math.max(0.01f, draftProb));

            if (acceptProb >= ACCEPT_THRESHOLD) {
                accepted++;
            } else {
                break; // 第一个拒绝后停止
            }
        }

        // 更新统计
        totalTokens   += draft.tokens.size();
        acceptedTokens += accepted;
        totalRounds++;

        VerifyResult result = new VerifyResult(
            accepted, draft.tokens.size(), serverRiskLevel, serverScoreInt
        );

        // 标记是否服务端修正了草稿结论
        result.corrected = !serverRiskLevel.equals(draft.riskLevel);

        Log.d(TAG, String.format(
            "Verify: accepted=%d/%d α=%.2f speedup=%.1fx corrected=%b",
            accepted, draft.tokens.size(),
            result.acceptanceRate, result.speedupFactor, result.corrected
        ));

        return result;
    }

    /** 估算服务端主模型在给定位置的 Token 概率 */
    private float estimateServerProb(float serverScore, int position) {
        float base = serverScore / 100f;
        return Math.max(0.05f, base - position * 0.01f);
    }

    // ── 统计信息 ───────────────────────────────────────────────
    public float getOverallAcceptanceRate() {
        return totalTokens > 0 ? (float) acceptedTokens / totalTokens : 0.82f;
    }

    public float getAverageSpeedup() {
        float alpha = getOverallAcceptanceRate();
        float denom = 1f - alpha * GAMMA / (1f + GAMMA);
        return denom > 0 ? 1f / denom : 1f;
    }

    public int getTotalRounds()    { return totalRounds;   }
    public int getTotalTokens()    { return totalTokens;   }
    public int getAcceptedTokens() { return acceptedTokens; }

    public void resetStats() {
        totalTokens = acceptedTokens = totalRounds = 0;
    }
}
