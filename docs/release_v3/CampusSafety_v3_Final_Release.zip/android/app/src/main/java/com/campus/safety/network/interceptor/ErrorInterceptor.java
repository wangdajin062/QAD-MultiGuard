package com.campus.safety.network.interceptor;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.campus.safety.util.TokenManager;
import java.io.IOException;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

/**
 * 全局错误响应拦截器
 * - 401 Unauthorized → 清除 Token + 广播登出事件
 * - 429 Rate Limit → 记录日志（UI 层 Toast 提示）
 * - 5xx Server Error → 记录日志
 */
public class ErrorInterceptor implements Interceptor {

    public static final String ACTION_UNAUTHORIZED  = "com.campus.safety.ACTION_UNAUTHORIZED";
    public static final String ACTION_RATE_LIMITED  = "com.campus.safety.ACTION_RATE_LIMITED";
    public static final String ACTION_SERVER_ERROR  = "com.campus.safety.ACTION_SERVER_ERROR";

    private final Context ctx;

    public ErrorInterceptor(Context ctx) { this.ctx = ctx.getApplicationContext(); }

    @NonNull @Override
    public Response intercept(@NonNull Chain chain) throws IOException {
        Request req = chain.request();
        Response resp;
        try {
            resp = chain.proceed(req);
        } catch (IOException e) {
            // 网络异常本身也广播
            LocalBroadcastManager.getInstance(ctx).sendBroadcast(
                new Intent(ACTION_SERVER_ERROR).putExtra("msg", e.getMessage()));
            throw e;
        }

        int code = resp.code();
        if (code == 401) {
            Log.w("ErrorIntercept", "401 Unauthorized — clearing token");
            TokenManager.clear(ctx);
            LocalBroadcastManager.getInstance(ctx).sendBroadcast(
                new Intent(ACTION_UNAUTHORIZED));
        } else if (code == 429) {
            Log.w("ErrorIntercept", "429 Rate Limited");
            LocalBroadcastManager.getInstance(ctx).sendBroadcast(
                new Intent(ACTION_RATE_LIMITED));
        } else if (code >= 500) {
            Log.e("ErrorIntercept", "5xx Server Error: " + code);
            LocalBroadcastManager.getInstance(ctx).sendBroadcast(
                new Intent(ACTION_SERVER_ERROR).putExtra("code", code));
        }
        return resp;
    }
}
